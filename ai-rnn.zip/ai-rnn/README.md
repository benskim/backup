# 딥러닝 자연어 & 시계열 데이터 처리 핵심 알고리즘의 원리와 활용
## 1. NLP & Word Embedding   
* 텍스트 데이터 다루기
* 텍스트 데이터 처리를 위한 BOW 모델
* 텍스트 데이터 처리 실습
<br>- 텍스트 분류(Text Classification) 실습 - 20 뉴스그룹 분류
<br>- 감성 분석(Sentiment Analysis) 실습 - IMDB 영화평
<br>- 토픽 모델링(Topic Modeling) 실습 - 20 뉴스그룹
<br>- 문서 군집화(Document Clustering) 실습 - Opinion Review
<br>-문서의 유사도(Cosine Similarity) 실습 - Opinion Review
* Word Embedding - Word2Vec
## 2. RNN/GRU/LSTM 알고리즘의 이해와 활용  
* Why sequence models & Notation
* RNN 아키텍처 및 알고리즘의 이해와 활용
* LSTM 아키텍처 및 알고리즘의 이해와 활용
* Language Model and Sentence Generation
* Gated Recurrent Unit (GRU) 아키텍처
## 3. Sequence models & Attention mechanism 
* Sequence Model seq2seq의 원리와 아키텍처
* Sequence Model seq2seq의 Toy Problem 구현
* Attention Mechanism의 동작과 구현
* Attention을 갖춘 seq2seq 구현과 응용
## 4. VAE & SketchRNN 
* Auto Encoder
* VAE (Variational Auto Encode)
* Sketch-RNN 구조와 알고리즘의 이해

```
## create THE virtual env for rnn

cd E:\AI-RNN
conda-env --help
conda-env list # conda info --envs 같음
conda list | findstr python # package list 
conda-env create -f .\env-rnn.yml # 파일내용대로 가상환경 설치
conda-env remove -n rnn # 에러발생시, 가상환경 삭제


conda activate rnn
jupyter notebook # + spyder은 app click

# github == https://github.com/edu-cafe/ai-rnn

# text analysis and NLP history 
## 서로 다른 갈래(피처추출 vs 챗봇,번역)로 시작했으나 함께 연구발전중
### 텍스트분석도 연구발전하면서 연구분야가 세분화됨
### 1. 텍스트분류 - 알고리즘:지도학습
### 2. 감성분석 - 알고리즘:비지도학습 추가 (감성단어 사전 필요)
### 3. 텍스트요약 - topic modeling (main-sub topic 분류)
### 4. 텍스트 군집화 - 알고리즘: 유사도 

## symbolic AI --> ML --> DL
#feature engineering(추출)의 방법에 따라 분류됨.
## 모델의 계수를 사람이 함
## 모델의 계수를 기계가 학습함.
## 모델의 피쳐의 개수, 어떤 피쳐를 추출할지를 기계가 함.

#feature engineering(벡터화)의 방법에 따라 분류됨.
## 사용방법에 따라 input data의 모양도 다르다(비정형-> 정형 데이터).
## bow -> bow or word2vec-> word2vec 
## bow :단어의 빈도수 or TF-IDF , word2vec : 단어 고유의 벡터
```

 
