#!/bin/sh
wget http://files.grouplens.org/papers/ml-100k.zip
unzip ml-100k.zip
